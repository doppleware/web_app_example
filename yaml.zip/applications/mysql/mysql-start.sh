#!/usr/bin/env bash

echo "****************************************************************"
echo "Restarting MYSQL"
echo "****************************************************************"
systemctl restart mysql.service
